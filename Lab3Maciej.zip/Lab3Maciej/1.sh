#!/bin/bash
echo "Podaj swoje imię: "
read imie
echo "Podaj swoje nazwisko: "
read nazwisko
echo "Podaj swój rok urodzenia: "
read rok_urodzenia

aktualny_wiek=$(($(date +%Y)-$rok_urodzenia))

echo "Witaj $imie $nazwisko! Masz $aktualny_wiek lat."

echo "Obliczam silnię..."
silnia_rekurencja(){
	if [ $1 -le 1 ]; then
		echo 1
	else
		echo $(($1 * $(silnia_rekurencja $(($1-1)))))
	fi
}

silnia_petla(){
	wynik=1
	for ((i=1; i<=$1; i++))
	do
		wynik=$(($wynik * $i))
	done
	echo $wynik
}

echo "Silnia rekurencyjnie: $(silnia_rekurencja $aktualny_wiek)"
echo "Silnia przez pętlę: $(silnia_petla $aktualny_wiek)"

echo "$imie,$nazwisko,$rok_urodzenia,$aktualny_wiek,$(silnia_rekurencja $aktualny_wiek)\n$(silnia_petla $aktualny_wiek)">> daneUsera.txt