#!/bin/bash

day=$1
month=$2

if [ $# -ne 2 ]; then
	echo "Error. Wrong input. You have to provide 2 arguments: day and month" > plik2
	echo "Error. Wrong input. You have to provide 2 arguments: day and month"
	exit
fi

weekDay=$(date -d "$month/$day/2022" +%A)

if [ -z "$weekDay" ]; then
	echo "Error. The date is incorrect" > plik2
	echo "Error. The date is incorrect"
	exit
fi

echo "$weekDay" > plik1
echo "$weekDay"
exit