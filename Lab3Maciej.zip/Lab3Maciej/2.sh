#!/bin/bash
if [ $# -eq 0 ]
then
   echo "Podaj nazwę pliku: "
   read nazwaPliku
else
   nazwaPliku=$1
fi

if [ ! -f "Zad1" ]
then
   echo "Brak pliku Zad1!"
   exit 1
fi

if ! echo $PATH | grep -q "$(pwd)"
then
   export PATH="$PATH:$(pwd)"
fi

if [ -d "daneUsera" ]
then
   rm -r daneUsera
fi

mkdir daneUsera
mv $nazwaPliku daneUsera

echo "Zawartość katalogu $(pwd):"
ls >> daneUsera/$nazwaPliku